To generate the plots of the paper, run the following command:
python3 ./result_visualization.py
