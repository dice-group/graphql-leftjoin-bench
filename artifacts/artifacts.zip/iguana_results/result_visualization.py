import matplotlib.pyplot as plt
import numpy as np
import os
import rdflib
from collections import defaultdict
import pandas as pd

def iguana_results(dataset_dir):
    # rdf/s URIs
    rdf_type_uri = rdflib.URIRef('http://www.w3.org/1999/02/22-rdf-syntax-ns#type')
    rdfs_label_uri = rdflib.URIRef('http://www.w3.org/2000/01/rdf-schema#label')
    rdfs_id = rdflib.URIRef('http://www.w3.org/2000/01/rdf-schema#ID')
    # iguana URIs
    suite_uri = rdflib.URIRef('http://iguana-benchmark.eu/class/Suite')
    query_uri = rdflib.URIRef('http://iguana-benchmark.eu/properties/query')
    query_id_uri = rdflib.URIRef('http://iguana-benchmark.eu/properties/queryID')
    experiment_uri = rdflib.URIRef('http://iguana-benchmark.eu/properties/experiment')
    dataset_uri = rdflib.URIRef('http://iguana-benchmark.eu/properties/dataset')
    task_uri = rdflib.URIRef('http://iguana-benchmark.eu/properties/task')
    connection_uri = rdflib.URIRef('http://iguana-benchmark.eu/properties/connection')
    n_workers_uri = rdflib.URIRef('http://iguana-benchmark.eu/properties/noOfWorkers')
    # metrics' URIs
    task_metrics = {
        'AvgQPS': rdflib.URIRef('http://iguana-benchmark.eu/properties/AvgQPS'),
        'pAvgQPS': rdflib.URIRef('http://iguana-benchmark.eu/properties/penalizedAvgQPS'),
        'QMPH': rdflib.URIRef('http://iguana-benchmark.eu/properties/QMPH')
    }
    query_metrics = {
        'QPS': rdflib.URIRef('http://iguana-benchmark.eu/properties/QPS'),
        'pQPS': rdflib.URIRef('http://iguana-benchmark.eu/properties/penalizedQPS'),
        'failed': rdflib.URIRef('http://iguana-benchmark.eu/properties/failed')
    }
    iguana_rdf_graph = rdflib.Graph()
    for file in sorted(os.listdir(os.path.dirname(dataset_dir))):
        iguana_rdf_graph.parse(os.path.join(dataset_dir, file), format='nt')
    results = dict()
    # iterate over the suites
    for suite in iguana_rdf_graph.subjects(rdf_type_uri, suite_uri):
        # iterate over the experiments
        for experiment in iguana_rdf_graph.objects(suite, experiment_uri):
            # get the dataset of the experiment
            dataset = [d for d in iguana_rdf_graph.objects(experiment, dataset_uri)][0]
            dataset_label = [label.toPython() for label in iguana_rdf_graph.objects(dataset, rdfs_label_uri)][0]
            if dataset_label not in results.keys():
                results[dataset_label] = defaultdict(dict)
            # iterate over the tasks
            for task in sorted(iguana_rdf_graph.objects(experiment, task_uri), key=lambda id: int(str(id).split('/')[-1])):
                n_workers = [x.toPython() for x in iguana_rdf_graph.objects(task, n_workers_uri)][0]
                # iterate over the connections
                for connection in iguana_rdf_graph.objects(task, connection_uri):
                    connection_label = [label.toPython() for label in
                                        iguana_rdf_graph.objects(connection, rdfs_label_uri)][0]
                    if n_workers not in results[dataset_label][connection_label]:
                        results[dataset_label][connection_label][n_workers] = dict()
                        for m in task_metrics.keys():
                            results[dataset_label][connection_label][n_workers][m] = list()
                        for m in query_metrics.keys():
                            results[dataset_label][connection_label][n_workers][m] = list()
                    # collect info for tasks
                    for (tmetric_name, tmetric_uri) in task_metrics.items():
                        results[dataset_label][connection_label][n_workers][tmetric_name].append(
                            [res.toPython() for res in iguana_rdf_graph.objects(task, tmetric_uri)][0]
                        )
                    # collect info for queries
                    for (qmetric_name, qmetric_uri) in query_metrics.items():
                        metric_results = dict()
                        for query in iguana_rdf_graph.objects(task, query_uri):
                            query_id = [res.toPython() for res in iguana_rdf_graph.objects(query, query_id_uri / rdfs_id)][0]
                            query_res = [res.toPython() for res in iguana_rdf_graph.objects(query, qmetric_uri)][0]
                            metric_results[query_id] = query_res
                        results[dataset_label][connection_label][n_workers][qmetric_name].append(metric_results)
    return pd.DataFrame.from_dict(results)


# Generate plots for GraphQL benchmarks
def graphql_plots(tentris_color, tentrisb_color, neo4j_color, results_dir):
    colors = dict()
    colors["TentrisLJ"] = tentris_color
    colors["TentrisLJBase"] = tentrisb_color
    colors["Neo4j"] = neo4j_color
    # iguana results
    graphql_qts_qm_iguana_res = iguana_results(results_dir + "graphql/qm/")
    graphql_all_t_iguana_res = iguana_results(results_dir + "graphql/all/")

    # plot generation for the first benchmark -- pAvgQPS
    graphql_qts_qm_labels = ['QT' + str(i) for i in range(1, 12)]
    graphql_qts_qm_x = np.arange(len(graphql_qts_qm_labels))
    graphql_width = 0.3
    dataset = graphql_qts_qm_iguana_res.keys()[0]
    graphql_qts_qm_res = graphql_qts_qm_iguana_res[dataset]
    tentris_pos = graphql_width
    neo4j_pos = - graphql_width
    metrics = ['pAvgQPS']
    for metric in metrics:
        fig, ax = plt.subplots()
        ax.bar(graphql_qts_qm_x + tentris_pos, graphql_qts_qm_res['TentrisLJ'][1][metric], graphql_width,
               label='TentrisLJ', log=True, color=tentris_color, edgecolor='white')
        ax.bar(graphql_qts_qm_x, graphql_qts_qm_res['TentrisLJBase'][1][metric], graphql_width,
               label='TentrisLJBase', log=True, color=tentrisb_color, edgecolor='white', hatch='\/')
        ax.bar(graphql_qts_qm_x + neo4j_pos, graphql_qts_qm_res['Neo4j'][1][metric], graphql_width,
               label='Neo4j', log=True, color=neo4j_color, edgecolor='white')
        ax.set_ylabel(metric, fontsize=14)
        ax.set_xlabel('Query Templates', fontsize=14)
        ax.set_xticks(graphql_qts_qm_x)
        ax.set_xticklabels(graphql_qts_qm_labels)
        ax.tick_params(axis='y', which='major', labelsize=14)
        ax.legend(fontsize=12)
        fig.tight_layout()
        fig.savefig('./g_' + metric.lower() + '.pdf')
        #cairosvg.svg2pdf(url='./g_' + metric.lower() + '.svg', write_to='./g_' + metric.lower() + '.pdf')

    # boxplots for qps -- one boxplot per system
    graphql_qps_width = 0.4
    n_queries = 110
    qps_fig, qps_ax = plt.subplots()
    labels = ["Neo4j", "TentrisLJBase", "TentrisLJ"]
    qps_data = dict()
    qps_data["Neo4j"] = [y for x in graphql_qts_qm_res['Neo4j'][1]['QPS'] for y in x.values()]
    qps_data["TentrisLJBase"] = [y for x in graphql_qts_qm_res['TentrisLJBase'][1]['QPS'] for y in x.values()]
    qps_data["TentrisLJ"] = [y for x in graphql_qts_qm_res['TentrisLJ'][1]['QPS'] for y in x.values()]
    step = graphql_qps_width / n_queries
    qps_ax.boxplot(qps_data.values(), widths=graphql_qps_width, showfliers=False, positions=np.arange(len(labels)))
    for i, system in enumerate(labels):
        start = i - 0.2
        end = start + (step * n_queries)
        x = np.linspace(start, end, n_queries)
        qps_ax.scatter(x, qps_data[system], color=colors[system], marker='*')
    qps_ax.set_ylabel('QPS', fontsize=14)
    qps_ax.set_yscale('log')
    qps_ax.set_xticks(np.arange(len(labels)))
    qps_ax.set_xticklabels(labels)
    qps_ax.tick_params(axis='both', which='major', labelsize=14)
    qps_fig.tight_layout()
    qps_fig.savefig('./g_qps.pdf')
    #cairosvg.svg2pdf(url='./g_qps.svg', write_to='./g_qps.pdf')

    # plot generation for second benchmark
    metric = 'pAvgQPS'
    graphql_all_t_labels = [1, 4, 8, 16]
    fig, ax = plt.subplots()
    dataset = graphql_all_t_iguana_res.keys()[0]
    graphql_all_t_res = graphql_all_t_iguana_res[dataset]

    t_values = [w * r for w in sorted(graphql_all_t_res['TentrisLJ'].keys())[:4] for r in graphql_all_t_res['TentrisLJ'][w][metric]]
    ax.plot(graphql_all_t_labels[:4], t_values, label='TentrisLJ', color=tentris_color, marker='*',
            linestyle='dashed')
    ax.text(graphql_all_t_labels[0] - 0.5, t_values[0] + 100, int(t_values[0]), horizontalalignment='left',
            verticalalignment='top', color=tentris_color, fontsize=13)

    for i in range(1, len(t_values)):
        ax.text(graphql_all_t_labels[i], t_values[i], int(t_values[i]), horizontalalignment='right',
                verticalalignment='bottom', color=tentris_color, fontsize=13)
    tb_values = [w * r for w in sorted(graphql_all_t_res['TentrisLJBase'].keys())[:4] for r in graphql_all_t_res['TentrisLJBase'][w][metric]]
    ax.plot(graphql_all_t_labels[:4], tb_values, label='TentrisLJBase', color=tentrisb_color, marker='x', linestyle='dashed')

    for i in range(len(tb_values)-1):
        ax.text(graphql_all_t_labels[i], tb_values[i], int(tb_values[i]), horizontalalignment='left',
                verticalalignment='top', color=tentrisb_color, fontsize=13)
    ax.text(graphql_all_t_labels[3]-0.6, tb_values[3]-200, int(tb_values[3]), horizontalalignment='left',
            verticalalignment='top', color=tentrisb_color, fontsize=13)
    n_values = [w * r for w in sorted(graphql_all_t_res['Neo4j'].keys())[:4] for r in graphql_all_t_res['Neo4j'][w][metric]]
    ax.plot(graphql_all_t_labels[:4], n_values, label='Neo4j', color=neo4j_color, marker='o', linestyle='dashed')
    for i in range(len(t_values)):
        ax.text(graphql_all_t_labels[i], n_values[i], int(n_values[i]), horizontalalignment='right',
                verticalalignment='bottom', color=neo4j_color, fontsize=13)

    ax.set_ylabel(metric, fontsize=14)
    ax.set_xlabel('Number of Clients', fontsize=14)
    ax.legend(fontsize=13)
    ax.set_yscale('log')
    ax.set_xticks(graphql_all_t_labels[:4])
    ax.set_xticklabels(graphql_all_t_labels[:4])
    ax.tick_params(axis='both', which='major', labelsize=14)
    fig.tight_layout()
    fig.savefig('./g_scalability.pdf')
    #cairosvg.svg2pdf(url='./g_scalability.svg', write_to='./g_scalability.pdf')

    # histrogram for translation
    transl_fig, transl_ax = plt.subplots()
    transl_ax.bar(0, graphql_all_t_res['Neo4j'][1][metric], graphql_width, label='Neo4j', color=neo4j_color, edgecolor='white')
    transl_ax.bar(0.5, graphql_all_t_res['Neo4jTranslation'][1][metric], graphql_width, label='Neo4jRW', color=neo4j_color, edgecolor='white', hatch='\/')
    transl_ax.bar(1, graphql_all_t_res['TentrisLJ'][1][metric], graphql_width, label='TentrisLJ', color=tentris_color, edgecolor='white')
    transl_ax.set_xticks([0, 0.5, 1])
    transl_ax.set_ylabel(metric, fontsize=14)
    transl_ax.set_xticklabels(['Neo4j', 'Neo4jRW', 'TentrisLJ'])
    transl_ax.tick_params(axis='both', which='major', labelsize=14)
    fig.tight_layout()
    transl_fig.tight_layout()
    transl_fig.savefig('./g_translation.pdf')
    #cairosvg.svg2pdf(url='./g_translation.svg', write_to='./g_translation.pdf')

def sparql_plots_qm(ts_colors, result_dir):
    # pavgqps
    sparql_res_t = iguana_results(result_dir+"sparql/qm/")['watdiv10000']
    sparql_width = 0.15
    query_labels = ["L1", "L2", "L3", "L4", "L5", "S1", "S2", "S3", "S4", "S5", "S6", "S7", "F1", "F2", "F4", "F5"]
    qm_x = np.arange(len(query_labels))
    dataset = sparql_res_t.keys()[0]
    positions = [-0.3, -0.15, 0, 0.15, 0.3]
    metrics = ['pAvgQPS']
    for metric in metrics:
        fig, ax = plt.subplots()
        ax.bar(qm_x + positions[0], sparql_res_t['Blazegraph'][1][metric], sparql_width, label='Blazegraph', log=True, color=ts_colors['Blazegraph'])
        ax.bar(qm_x + positions[1], sparql_res_t['Fuseki'][1][metric], sparql_width, label='Fuseki', log=True, color=ts_colors['Fuseki'])
        ax.bar(qm_x + positions[2], sparql_res_t['GraphDB'][1][metric], sparql_width, label='GraphDB', log=True, color=ts_colors['GraphDB'])
        ax.bar(qm_x + positions[3], sparql_res_t['TentrisLJ'][1][metric], sparql_width, label='TentrisLJ', log=True, color=ts_colors['TentrisLJ'])
        ax.bar(qm_x + positions[4], sparql_res_t['Virtuoso'][1][metric], sparql_width, label='Virtuoso', log=True, color=ts_colors['Virtuoso'])
        ax.set_ylabel(metric, fontsize=14)
        ax.set_xlabel('Query Templates', fontsize=14)
        ax.set_xticks(qm_x)
        ax.set_xticklabels(query_labels)
        ax.tick_params(axis='y', which='major', labelsize=14)
        ax.legend(fontsize=11, ncol=5, columnspacing=0.5, handlelength=1, handletextpad=0.3)
        fig.tight_layout()
        fig.savefig('./s_' + metric.lower() + '.pdf')
        #cairosvg.svg2pdf(url='./s_' + metric.lower() + '.svg', write_to='./s_' + metric.lower() + '.pdf')
    # qps
    qps_width = 0.4
    n_queries = 160
    qps_fig, qps_ax = plt.subplots()
    labels = ["Blazegraph", "Fuseki", "GraphDB", "TentrisLJ", "Virtuoso"]
    qps_data = dict()
    qps_data["Blazegraph"] = [y for x in sparql_res_t['Blazegraph'][1]['QPS'] for y in x.values()]
    qps_data["Fuseki"] = [y for x in sparql_res_t['Fuseki'][1]['QPS'] for y in x.values()]
    qps_data["GraphDB"] = [y for x in sparql_res_t['GraphDB'][1]['QPS'] for y in x.values()]
    qps_data["TentrisLJ"] = [y for x in sparql_res_t['TentrisLJ'][1]['QPS'] for y in x.values()]
    qps_data["Virtuoso"] = [y for x in sparql_res_t['Virtuoso'][1]['QPS'] for y in x.values()]
    qps_ax.boxplot(qps_data.values(), widths=qps_width, showfliers=False, positions=np.arange(len(labels)))
    step = qps_width / n_queries
    for i, system in enumerate(labels):
        start = i - 0.2
        end = start + (step * n_queries)
        x = np.linspace(start, end, n_queries)
        qps_ax.scatter(x[:49], qps_data[system][:49], color=ts_colors[system], marker='o')
        qps_ax.scatter(x[50:119], qps_data[system][50:119], color=ts_colors[system], marker='*')
        qps_ax.scatter(x[120:], qps_data[system][120:], color=ts_colors[system], marker='+')
    legend_items = [plt.scatter([0], [0], color='black', marker='o', label='linear'),
                    plt.scatter([0], [0], color='black', marker='*', label='star'),
                    plt.scatter([0], [0], color='black', marker='+', label='flake')]
                    # plt.scatter([0], [0], color='black', marker='x', label='complex')]
    qps_ax.legend(handles=legend_items, title='Query Types', title_fontsize=12, fontsize=12, ncol=3, columnspacing=0.6, handletextpad=0.1)
    qps_ax.set_ylabel('QPS', fontsize=14)
    qps_ax.set_yscale('log')
    qps_ax.set_xticks(np.arange(len(labels)))
    qps_ax.set_xticklabels(labels)
    qps_ax.tick_params(axis='both', which='major', labelsize=14)
    qps_fig.tight_layout()
    qps_fig.savefig('./s_qm_qps.pdf')
    #cairosvg.svg2pdf(url='./s_qm_qps.svg', write_to='./s_qm_qps.pdf')

def sparql_plots(ts_colors, result_dir):
    sparql_res_t = iguana_results(result_dir+"sparql/t/")['watdiv10000']

    labels = list()
    sparql_qps_width = 0.6

    qps_data = list()
    qps_box_fig, qps_box_ax = plt.subplots()
    qps_hist_fig, qps_hist_ax = plt.subplots()
    query_labels = ["L1", "L2", "L3", "L4", "L5", "S1", "S2", "S3", "S4", "S5", "S6", "S7", "F1", "F2", "F4", "F5"]
    positions = [-0.3, -0.15, 0, 0.15, 0.3]
    for pos, system in enumerate(sparql_res_t.index.values):
        labels.append(system)
        color = ts_colors[system]
        qps_data_system = sparql_res_t[system][1]['QPS'][0]
        step = sparql_qps_width / len(qps_data_system)
        # different scatter plot for each query type (linear, star, flake, complex)
        linear_qps = list()
        star_qps = list()
        flake_qps = list()
        for i in range(5):
            linear_qps.append(qps_data_system[str(i)] if qps_data_system[str(i)] > 0 else 0.001)
        start = pos - sparql_qps_width / 2
        end = start + (step * len(linear_qps))
        x = np.linspace(start, end, len(linear_qps))
        qps_box_ax.scatter(x, linear_qps, color=color, marker='o')
        # star queries
        for i in range(5, 12):
            star_qps.append(qps_data_system[str(i)] if qps_data_system[str(i)] > 0 else 0.001)
        start = end
        end = start + (step * len(star_qps))
        x = np.linspace(start, end, len(star_qps))
        qps_box_ax.scatter(x, star_qps, color=color, marker='*')
        # flake queries
        for i in range(12, 16):
            flake_qps.append(qps_data_system[str(i)] if qps_data_system[str(i)] > 0 else 0.001)
        # linear incremental queries
        # for i in range (16, 17):
        #     linear_qps.append(qps_data_system[str(i)] if qps_data_system[str(i)] > 0 else 0.001)
        start = end
        end = start + (step * len(flake_qps))
        x = np.linspace(start, end, len(flake_qps))
        qps_box_ax.scatter(x, flake_qps, color=color, marker='+')
        qps_data.append(linear_qps + star_qps + flake_qps)
        qps_hist_ax.bar(np.arange(len(query_labels)) + positions[pos], qps_data[-1], width=0.15, label=system, log=True, color=color)

    # scalability plot
    workers_labels = [1, 4, 8, 16]
    fig, ax = plt.subplots()
    markers = ['*', 'o', 'D', '+', 'x']
    for system, color in ts_colors.items():
        workers = 4
        if system == 'GraphDB':
            workers = 1
            halign, valign = 'right', 'bottom'
        elif system == 'Blazegraph':
            workers = 4
            halign, valign = 'left', 'bottom'
        elif system == 'Fuseki':
            halign, valign = 'right', 'bottom'
        elif system == 'Virtuoso':
            workers = 4
            halign, valign = 'right', 'bottom'
        elif system == 'TentrisLJ':
            halign, valign = 'right', 'bottom'
        values = [w * r for w in sorted(sparql_res_t[system].keys())[:workers] for r in sparql_res_t[system][w]['pAvgQPS']]
        ax.plot(workers_labels[:workers], values, label=system, color=color, marker=markers.pop(), linestyle='dashed')
        for i in range(len(values)):
            ax.text(workers_labels[i]+0.2, values[i], int(values[i]), horizontalalignment=halign, verticalalignment=valign,
                    color=ts_colors[system], fontsize=13)
    ax.set_ylabel('pAvgQPS', fontsize=14)
    ax.set_xlabel('Number of Clients', fontsize=14)
    ax.legend(fontsize=12, ncol=2)
    ax.set_xticks(workers_labels[:4])
    ax.set_xticklabels(workers_labels[:4])
    ax.tick_params(axis='both', which='major', labelsize=14)
    ax.set_yscale('log')
    fig.tight_layout()
    fig.savefig('./s_scalability.pdf')
    # cairosvg.svg2pdf(url='./s_scalability.svg', write_to='./s_scalability.pdf')

if __name__ == '__main__':
    result_dir = "./"
    # color palette
    colors = list(plt.cm.get_cmap('Dark2').colors)
    # remove colors from the palette
    colors.pop(3)
    tentrisb_color = colors.pop(1)
    tentris_color = colors.pop()
    neo4j_color = colors.pop()
    ts_colors = {
        'TentrisLJ': tentris_color,
        'GraphDB': colors.pop(),
        'Fuseki': colors.pop(),
        'Virtuoso': colors.pop(),
        'Blazegraph': colors.pop()
    }
    graphql_plots(tentris_color, tentrisb_color, neo4j_color, result_dir)
    sparql_plots(ts_colors, result_dir)
    sparql_plots_qm(ts_colors, result_dir)
